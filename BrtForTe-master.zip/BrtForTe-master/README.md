# BrtForTe,V1.2

# A python Tool For Brute Force Attack On Emails or servers or Hash and Web :)

- This version is simple but in the next version the tool will be developed and will be able to do a lot of brute force attacks

- Tool screenshot

![](https://scontent.fjrs3-1.fna.fbcdn.net/v/t1.0-9/22196331_164739944108353_7495847684596479363_n.jpg?oh=05e3bdf87ab862e5bf6e61b766bb31ee&oe=5A3BBEAA)

# How You Install Tool:

1 > open your terminal

2 > and type this command: git clone https://github.com/Oseid/BrtForTe.git

- Note: if your not install git you can install tool zip file :) 

3 > type this command: cd BrtForTe/

4 > and type this command: chmod +x BrtForTe.py


- download complete !

- To run tool

./BrtForTe.py


# Usage:

type: ./BrtForTe.py -e or --examples To Know How usage :)

# That's All:

By Oseid Aldary

thanks for usage

have a nice day, goodbye :)
